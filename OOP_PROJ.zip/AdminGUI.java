package javaapplication14;

import java.util.ArrayList;
import java.util.Optional;
import javafx.application.Application;
import static javafx.collections.FXCollections.observableArrayList;
import javafx.geometry.Insets;
import javafx.stage.FileChooser;
import java.io.File;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.Background;
import javafx.scene.layout.BackgroundFill;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.CornerRadii;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;
import javafx.stage.Stage;

public class AdminGUI extends Application {

    static int rowN = 0;
    static int colN = 0;
    int UsersNodeCounter = 0;
    //int NodeCounter = 0;
    GridPane usersStack;
    GridPane moviesStack = createMovieStack();
    Stage primaryStage = new Stage();
    Scene scene;

    @Override
    public void start(Stage primaryStage) {
        login();
    }

    Scene admin(String username) {
        BorderPane root = new BorderPane();
        //moviesStack = createMovieStack();
        ScrollPane ScrollMovie = new ScrollPane(moviesStack);
        moviesStack.setPadding(new Insets(60));
        moviesStack.setHgap(30);
        moviesStack.setVgap(20);

        GridPane adminStack = createAdminStack(username);
        root.setCenter(adminStack);
        adminStack.setPadding(new Insets(60));
        adminStack.setHgap(30);
        adminStack.setVgap(20);

        usersStack = createUsersStack();
        usersStack.setPadding(new Insets(60));
        usersStack.setHgap(30);
        usersStack.setVgap(20);

        // Create header
        HBox headerPane = new HBox();
        headerPane.setBackground(new Background(new BackgroundFill(Color.web("#f83745"), CornerRadii.EMPTY, Insets.EMPTY)));
        Label label = new Label("     Cinema");
        label.setFont(Font.font("Verdana", FontWeight.BOLD, 14));
        label.setTextFill(Color.WHITE);
        label.setAlignment(Pos.CENTER);
        headerPane.getChildren().add(label);
        HBox headerPane2 = new HBox();
        headerPane2.setBackground(new Background(new BackgroundFill(Color.web("#ff424f"), CornerRadii.EMPTY, Insets.EMPTY)));
        Label label2 = new Label("\t\t\t\t\t\t\t\t\t Movies");
        headerPane2.getChildren().add(label2);
        label.setTextFill(Color.BLACK);
        label2.setFont(Font.font("Roboto", FontWeight.BOLD, 14));
        headerPane2.setMinWidth(1450);
        headerPane.setMinWidth(172);
        headerPane.setMinHeight(40);
        GridPane hs = new GridPane();
        hs.add(headerPane, 0, 0);
        hs.add(headerPane2, 1, 0);
        root.setTop(hs);

        GridPane rightPanel = new GridPane();
        ScrollPane rightWheel = new ScrollPane(rightPanel);

        rightPanel.setMinWidth(115.5);
        //rightPanel.setBackground(new Background(new BackgroundFill(Color.web("#191c1f"), CornerRadii.EMPTY, Insets.EMPTY)));

        root.setLeft(rightPanel);
        rightPanel.setStyle("-fx-background-color: #191c1f; -fx-padding: 10px;");

        Button Administration = new Button("Administration");
        Administration.setBackground(Background.EMPTY);
        Administration.setTextFill(Color.WHITE);
        /* Set font color to blue */
        Administration.setFont(Font.font("Montserrat", FontWeight.BOLD, 18));
        Administration.setOnAction(e -> {
            root.setCenter(adminStack);

        });
        Administration.setOnMouseEntered(e -> {
            Administration.setTextFill(Color.web("#db4e58"));
        });
        Administration.setOnMouseExited(e -> {
            Administration.setTextFill(Color.WHITE);
        });

        Button Moviesb = new Button("Movies");
        Moviesb.setBackground(Background.EMPTY);
        Moviesb.setTextFill(Color.WHITE);
        /* Set font color to blue */
        Moviesb.setFont(Font.font("Montserrat", FontWeight.BOLD, 18));
        Moviesb.setOnAction(e -> {
            root.setCenter(ScrollMovie);
        });
        Moviesb.setOnMouseEntered(e -> {
            Moviesb.setTextFill(Color.web("#db4e58"));
        });
        Moviesb.setOnMouseExited(e -> {
            Moviesb.setTextFill(Color.WHITE);
        });

        Button Usersb = new Button("Users");
        Usersb.setTextFill(Color.WHITE);
        /* Set font color to blue */
        Usersb.setFont(Font.font("Montserrat", FontWeight.BOLD, 18));
        Usersb.setBackground(Background.EMPTY);
        /* Set transparent background */
        Usersb.setOnAction(e -> {
            root.setCenter(usersStack);

        });
        Usersb.setOnMouseEntered(e -> {
            Usersb.setTextFill(Color.web("#db4e58"));
        });
        Usersb.setOnMouseExited(e -> {
            Usersb.setTextFill(Color.WHITE);
        });

        Button Login = new Button("Login");
        Login.setTextFill(Color.WHITE);
        Login.setFont(Font.font("Montserrat", FontWeight.BOLD, 18));
        Login.setBackground(Background.EMPTY);
        /* Set transparent background */
        Login.setOnAction(e -> {
            login();

        });
        Login.setOnMouseEntered(e -> {
            Login.setTextFill(Color.web("#db4e58"));
        });
        Login.setOnMouseExited(e -> {
            Login.setTextFill(Color.WHITE);
        });

        rightPanel.add(Administration, 0, 0);
        rightPanel.add(Moviesb, 0, 2);
        rightPanel.add(Usersb, 0, 3);
        rightPanel.add(Login, 0, 18);
        rightPanel.setVgap(20);

        // Button Moviesb = new Button("Movies");
        //   Button Moviesb = new Button("Movies");
//        ComboBox<String> menu1 = new ComboBox<>();
//        ObservableList<String> items = observableArrayList("Option 1", "Option 2", "Option 3");
//        menu1.setItems(items);
//        ComboBox<String> menu2 = new ComboBox<>();
//        ObservableList<String> items2 = observableArrayList("Option 1", "Option 2", "Option 3");
//        menu2.setItems(items2);
//        rightPanel.add(menu1, 0, 0);
//        rightPanel.add(menu2, 0, 1);
//        rightPanel.setVgap(10);
//        rightPanel.setPadding(new Insets(10));
//        // VBox left = new VBox();
//        Pane topPanel = new Pane();
//        topPanel.setStyle("-fx-background-color: #e0e0e0; -fx-border-color: #a0a0a0; -fx-padding: 10px;");
//        topPanel.setMinHeight(90);
//        root.setTop(topPanel);
        scene = new Scene(root, 800, 600);
        return scene;
//        primaryStage.setScene(scene);
//
//        primaryStage.setTitle("Admin Page ");
//        primaryStage.show();

    }

    GridPane createMovieStack() {
        GridPane moviesStack = new GridPane();
        moviesStack.setBackground(new Background(new BackgroundFill(Color.web("#222b31"), CornerRadii.EMPTY, Insets.EMPTY)));

        // TODO: Replace with your actual logic to retrieve movie data
        ArrayList<Movies> movies = Movies.getMovies();  // Assuming you have a method to fetch movie data
        VBox inceptionPane = moviePane(new Image("file:E:\\oopcinema\\inception.jpg"), "Inception", "SciFi");
        addMovie(inceptionPane, moviesStack);

        VBox egPane = moviePane(new Image("file:E:\\oopcinema\\endgame.jpg"), "Endgame", "Action");
        addMovie(egPane, moviesStack);

        VBox barbiePane = moviePane(new Image("file:E:\\oopcinema\\barbie.jpg"), "Barbie", "Drama, Romance");
        addMovie(barbiePane, moviesStack);

        VBox blueePane = moviePane(new Image("file:E:\\oopcinema\\blue elephant.jpg"), "Blue Elephant", "Action, Horror");
        addMovie(blueePane, moviesStack);

        VBox gnPane = moviePane(new Image("file:E:\\oopcinema\\gn.jpg"), "Goodnight", "Drama");
        addMovie(gnPane, moviesStack);

        // Add other elements to moviesStack (e.g., button to trigger adding more movies)
        return moviesStack;
    }

    GridPane createShowsStack() {
        GridPane showsStack = new GridPane();
        showsStack.setBackground(new Background(new BackgroundFill(Color.web("#222b31"), CornerRadii.EMPTY, Insets.EMPTY)));

        return showsStack;
    }

    GridPane createAdminStack(String username) {
        GridPane adminStack = new GridPane();
        adminStack.setBackground(new Background(new BackgroundFill(Color.web("#222b31"), CornerRadii.EMPTY, Insets.EMPTY)));

        // Image and Admin Name
        Image userPhoto = new Image("file:E:\\oopcinema\\user.png");
        ImageView movieView = new ImageView(userPhoto);
        movieView.setFitHeight(120);
        movieView.setFitWidth(120);
        adminStack.add(movieView, 0, 0);

        Label adminName = new Label(username);  // Add the admin name
        adminName.setTextFill(Color.WHITE);  // Set the label color to blue
        adminStack.add(adminName, 1, 0);

        // Dialog for user input
        Dialog<ButtonType> addUserDialog = new Dialog<>();
        addUserDialog.setTitle("Add User");

        VBox dialogContent = new VBox();
        TextField userNameField = new TextField();
        ChoiceBox<String> userTitleChoiceBox = new ChoiceBox<>(observableArrayList("Owner", "Admin", "Receptionist", "Guest"));
        Button confirmButton = new Button("Add");
        dialogContent.getChildren().addAll(userNameField, userTitleChoiceBox, confirmButton);
        addUserDialog.getDialogPane().setContent(dialogContent);

        confirmButton.setOnAction(e -> {
            addUserDialog.setResult(ButtonType.OK);  // Indicate success
            addUserDialog.close();
        });

        // Button to trigger the dialog
        Button addUserButton = new Button("Add User");
        addUserButton.setOnAction(e -> {
            Optional<ButtonType> result = addUserDialog.showAndWait();
            if (result.isPresent() && result.get() == ButtonType.OK) {
                String name = userNameField.getText();  // Re-access name and title
                String title = userTitleChoiceBox.getValue();
                // Create the user pane using the retrieved name and title
                VBox userPane = userPane(name, title);
                addUser(userPane);
            }
        });

        adminStack.add(addUserButton, 3, 5);
        Button addMovieButton = new Button("Add Movie");
        adminStack.add(addMovieButton, 4, 5);

        Dialog<ButtonType> addMovieDialog = new Dialog<>();
        addMovieDialog.setTitle("Add Movie");

        VBox MovieContent = new VBox();
        TextField titleField = new TextField("Name");
        TextField categoryField = new TextField("Category");
        TextField MovieIDField = new TextField("ID");
        TextField MoviePriceField = new TextField("Price");
        MovieContent.getChildren().addAll(titleField, categoryField, MovieIDField, MoviePriceField);
        Button choosePosterButton = new Button("Browse...");
        TextField posterPathField = new TextField();
        posterPathField.setEditable(false); // Make it read-only to indicate selection
        choosePosterButton.setOnAction(e1 -> {
            FileChooser fileChooser = new FileChooser();
            File selectedFile = fileChooser.showOpenDialog(null);
            if (selectedFile != null) {
                posterPathField.setText(selectedFile.getAbsolutePath());
            }
        });
        MovieContent.getChildren().addAll(choosePosterButton, posterPathField);
        addMovieDialog.getDialogPane().setContent(MovieContent);

        addMovieButton.setOnAction(e -> {
            // Create the add movie dialog
            Optional<ButtonType> Movieresult = addMovieDialog.showAndWait();
            if (Movieresult.isPresent() && Movieresult.get() == ButtonType.OK) {

                String name = titleField.getText();  // Re-access name and title
                String cat = categoryField.getText();
                // Create the user pane using the retrieved name and title
                Image s = new Image("file:" + posterPathField.getText());
                VBox moviePane = moviePane(s, name, cat);
                addMovie(moviePane, moviesStack);
            }
            // Poster image selection
        });

        // Confirm button with action
        Button confirmMovieButton = new Button("Add");
        confirmMovieButton.setOnAction(e2 -> {
            // Close the dialog
            System.out.println("test");
            addMovieDialog.setResult(ButtonType.OK);  // Set the result to OK
            addMovieDialog.close();
            System.out.println("66");

        });
        MovieContent.getChildren().add(confirmMovieButton);
        // Set the dialog content and show it
        addMovieDialog.getDialogPane().setContent(MovieContent);

        // ... (rest of the code remains(); the same)
        return adminStack;
    }

    GridPane createUsersStack() {
        GridPane usersStack = new GridPane();
        usersStack.setBackground(new Background(new BackgroundFill(Color.web("#222b31"), CornerRadii.EMPTY, Insets.EMPTY)));
        VBox userpane = userPane("Bakr", "Owner");
        usersStack.add(userpane, 0, 0);

        return usersStack;
    }

    // ll tarekh de 
    private VBox moviePane(Image photo, String name, String Category) {
        VBox pane = new VBox();
        ImageView movieView = new ImageView(photo);
        movieView.setFitHeight(142);
        movieView.setFitWidth(100);
        Label nameL = new Label(name);
        nameL.setFont(Font.font("Verdana", FontWeight.BOLD, 14));
        nameL.setTextFill(Color.WHITE);

        Label catL = new Label(Category);
        catL.setTextFill(Color.GREY);
        pane.getChildren().addAll(movieView, nameL, catL);

        return pane;
    }

    private VBox showPane(Image photo, String name, String Time, String Hall) {
        VBox pane = new VBox();
        ImageView movieView = new ImageView(photo);
        movieView.setFitHeight(142);
        movieView.setFitWidth(100);
        Label nameL = new Label(name);
        nameL.setFont(Font.font("Verdana", FontWeight.BOLD, 14));
        nameL.setTextFill(Color.WHITE);

        //Label catL = new Label(Category);
        // catL.setTextFill(Color.GREY);
        pane.getChildren().addAll(movieView, nameL);

        return pane;
    }

    private VBox userPane(String name, String Title) {
        VBox pane = new VBox();
        Image userphoto = new Image("file:E:\\oopcinema\\user.png");
        ImageView movieView = new ImageView(userphoto);
        movieView.setFitHeight(120);
        movieView.setFitWidth(120);
        Label nameL = new Label(name);
        nameL.setFont(Font.font("Verdana", FontWeight.BOLD, 14));
        nameL.setTextFill(Color.WHITE);

        Label catL = new Label(Title);
        catL.setTextFill(Color.GREY);
        pane.getChildren().addAll(movieView, nameL, catL);

        return pane;
    }

    void addMovie(VBox moviePane, GridPane movieStack) {

        //  int colN = 0 ;
        //  int rowN = 0;
        if (colN == 3) {
            colN = 0;
        }
        int size = movieStack.getChildren().size();
        if (size % 3 == 0) {
            rowN++;
        }
        movieStack.add(moviePane, colN++, rowN);

    }

    void addUser(VBox userPane) {

        usersStack.add(userPane, 0, ++UsersNodeCounter);
        // nodeCounter++;
    }

    public static void main(String[] args) {
        Admin bakr = new Admin("Bakr", "0000");
        launch(args);
    }

    public void login() {
        BorderPane header = new BorderPane();
        Image logoImage = new Image("file:path/to/logo.png");  // Replace with your logo path
        ImageView logoView = new ImageView(logoImage);
        Label title = new Label("Cinema Booking System");
        title.setFont(Font.font("Arial", FontWeight.BOLD, 24));
        header.setLeft(logoView);
        header.setCenter(title);

        GridPane loginForm = new GridPane();
        loginForm.setHgap(10);
        loginForm.setVgap(10);
        loginForm.setPadding(new Insets(20));

        Label usernameLabel = new Label("Username:");
        TextField usernameField = new TextField("bakr");
        Label passwordLabel = new Label("Password:");
        PasswordField passwordField = new PasswordField();
        ChoiceBox<String> userTypeChoice = new ChoiceBox<>();
        userTypeChoice.getItems().addAll("Admin", "Receptionist", "Guest");
        userTypeChoice.setValue("Admin");
        Button loginButton = new Button("Login");
        Button guestLoginButton = new Button("Continue as Guest");

        loginForm.add(usernameLabel, 0, 0);
        loginForm.add(usernameField, 1, 0);
        loginForm.add(passwordLabel, 0, 1);
        loginForm.add(passwordField, 1, 1);
        loginForm.add(userTypeChoice, 1, 2);
        loginForm.add(loginButton, 1, 3);
        loginForm.add(guestLoginButton, 1, 4);

        HBox links = new HBox();
        links.setSpacing(10);
        links.setAlignment(Pos.CENTER_RIGHT);
        Label forgotPasswordLink = new Label("Forgot Password?");
        Label createAccountLink = new Label("Create New Account");
        forgotPasswordLink.setTextFill(Color.BLUE);
        createAccountLink.setTextFill(Color.BLUE);
        links.getChildren().addAll(forgotPasswordLink, createAccountLink);

        VBox mainLayout = new VBox();
        mainLayout.getChildren().addAll(header, loginForm, links);
        mainLayout.setAlignment(Pos.CENTER);
        mainLayout.setSpacing(20);

        Scene login = new Scene(mainLayout, 500, 400);
        // login.getStylesheets().add("style.css");  // Link to your CSS file (optional)
        primaryStage.setScene(login);
        primaryStage.setTitle("Cinema Booking System - Login");
        primaryStage.show();

        loginButton.setOnAction(e -> {
            String username = usernameField.getText();
            String password = passwordField.getText();
            String userType = userTypeChoice.getValue();

            if (Admin.isAdmin(username)) {
                System.out.println("adminnn");
                if (userType.equals("Admin")) {
                    primaryStage.setScene(admin(username));
                }
            } else {
                System.out.println("msh admin");
                Alert alert = new Alert(Alert.AlertType.ERROR);
                alert.setTitle("Login Failed");
                alert.setHeaderText("Invalid username or password");
                alert.setContentText("Please check your credentials and try again.");
                alert.showAndWait();
            }
        });

    }
}
