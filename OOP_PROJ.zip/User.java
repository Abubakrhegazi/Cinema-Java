package javaapplication14;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */


import java.util.ArrayList;
import java.util.Scanner;
public abstract class User { //mosh h create mno object dah 3ashan al admin w al r w al g y inherait mno al haga

    private String username;
    private String pass;

    public User() {
    }
    public User(String username, String pass) {
        this.username = username;
        this.pass = pass;
    }

    //static ArrayList users = new ArrayList<User>();
    public static ArrayList<User> users = new ArrayList<>();

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getPass() {
        return pass;
    }

    public void setPass(String pass) {
        this.pass = pass;
    }

    public ArrayList<User> getUsers() {
        return users;
    }

    public void setUsers(ArrayList users) {
        this.users = users;
    }
    
    public void view_allmovies(){
       for(int i=0;i<Movies.getMovies().size();i++){
           System.out.println(i);
       }
    }

    static boolean isUser(String name){
        for(User s: users){
            if(s.username.equalsIgnoreCase(name))
                return true;
        }
        return false;
    }
    
}