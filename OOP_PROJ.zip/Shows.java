/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package javaapplication14;

import java.io.File;
import java.io.PrintWriter;
import java.io.FileWriter;
import java.util.ArrayList;
import java.util.Scanner;
import java.io.IOException;
public class Shows {
    private static String file = "/Users/mohammedwalidadawy/Desktop/uni/project/FinalProject_/src/ShowReportt";
    static ArrayList<Shows> allshows = new ArrayList<>();
    private int showsBookings;
    private String name;
    private double duration;
    private double startDate ,EndTime;
    private String hallNumber;
    private int price;
    private String showID;
    Movies movie; //aggregation kol show has a movie
    Halls hall; //aggregation kol show has a specific hall
//    public Shows(String name, double startDate, double duration, String hallNumber, int price) {
//        this.name = name;
//        this.startDate = startDate;
//        this.duration = duration;
//        this.hallNumber = hallNumber;
//        this.showsBookings = 0;
//        this.price = price;
//        allshows.add(this);
//    }
    public Shows(String name, double startDate, double duration, Movies movie, Halls hall, int price) {
        this.startDate = startDate;
        this.EndTime = EndTime;
        this.name=name;
        this.movie = movie;
        this.showsBookings = 0;
        this.hall = hall;
        allshows.add(this);
        this.price = price;
        this.showID = showID;
    }
    public void setEndDate(double EndTime) {
        this.EndTime = EndTime;
    }
    public void setHallID(Halls hall) {
        this.hall = hall;
    }
    public Shows() {
        this.showsBookings = 0;
    }
    public void setMovie(Movies movie) {
        this.movie = movie;
    }
    public void setStartDate(double startTime) {
        this.startDate = startTime;
    }
    public String getShowID() {
        return showID;
    }
    public void setEndTime(double EndTime) {
        this.EndTime = EndTime;
    }
    public double getEndTime() {
        return EndTime;
    }
    public void setShowID(String showID) {
        this.showID = showID;
    }
    public Movies getMovie() {
        return movie;
    }
    public double getDuration() {
        return duration;
    }

    public int getShowsBookings() {
        return showsBookings;
    }

    public String getHallNumber() {
        return hallNumber;
    }

    public double getStartDate() {
        return startDate;
    }

    public String getName() {
        return name;
    }

    public int getPrice() {
        return price;
    }

    public void book() {
        showsBookings++;
    }

    public String date() {
        //duration in minutes
        double dateDuration=duration/60;
        int startHours = (int) startDate ;
        int startMinutes = (int) ((startDate - startHours) * 60);
        //double endDate = (startDate + duration);
        int endHours = (int) (startDate + dateDuration) ;
        int endMinutes=(int) (((startDate + dateDuration)-endHours)*60);
        startHours = (startHours % 12 == 0) ? 12 : startHours % 12;
        endHours = (endHours % 12 == 0) ? 12 : endHours % 12;
        String formattedStartMinutes = String.format("%02d", startMinutes);
        String formattedEndMinutes = String.format("%02d", endMinutes);
        String start = (startHours < 12) ? "AM" : "PM";
        String end = (endHours < 12) ? "AM" : "PM";
        return(startHours+":"+formattedStartMinutes+" "+start+" to "+endHours+":"+formattedEndMinutes+" "+end);
    }
    public static Shows mostBookedShow() {
        Shows mostBooked = null;
        int maxNum = -1;
        for (Shows show : allshows) {
            if (show.getShowsBookings() > maxNum) {
                maxNum = show.getShowsBookings();
                mostBooked = show;
            }
        }
        return mostBooked;
    }

    public static Shows mostRevenue() {
        Shows mostRevShow = null;
        int maxRevenue = -1;

        for (Shows show : allshows) {
            int revenue = show.getPrice() * show.getShowsBookings();
            if (revenue > maxRevenue) {
                maxRevenue = revenue;
                mostRevShow = show;
            }
        }
        return mostRevShow;
    }

    public void viewReports() {
        try (Scanner s = new Scanner(new File(file))) {
            while (s.hasNextLine()) {
                String read = s.nextLine();
                System.out.println(read);
            }
        } catch (IOException e) {
            System.out.println(e);
        }
    }
}