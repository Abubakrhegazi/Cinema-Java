package javaapplication14;
//
///*
// * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
// * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
// */
//

import java.io.File;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.Scanner;

public class Booking {

    private String user_name;
    private String recep_name;
    private String type;
    private String movieName;
    private int bookingNo;
    private int rating;
    private int price;
    private int time;
    // private int hall_id; //hall class org
    //    private int seatNo;
    private HallType halltype;
    private Halls hall;
    static int TotalBookings = 0;
    public static ArrayList<Booking> allbookings = new ArrayList<>();

    public void setUser_name(String user_name) {
        this.user_name = user_name;
    }

    public void setRecep_name(String recep_name) {
        this.recep_name = recep_name;
    }

    public void setType(String type) {
        this.type = type;
    }

    public void setMovieName(String movieName) {
        this.movieName = movieName;
    }

    public void setBookingNo(int bookingNo) {
        this.bookingNo = bookingNo;
    }

    public void setRating(int rating) {
        this.rating = rating;
    }

    public void setPrice(int price) {
        this.price = price;
    }

    public void setTime(int time) {
        this.time = time;
    }

    public void setHalltype(HallType halltype) {
        this.halltype = halltype;
    }

    ////org
//    public void setHall_id(int hall_id) {
//        this.hall_id = hall_id;
//    }
//    public void setSeatNo(int seatNo) {
//        this.seatNo = seatNo;
//    }
    
    public String getUser_name() {
        return user_name;
    }

    public String getRecep_name() {
        return recep_name;
    }

    public String getType() {
        return type;
    }

    public String getMovieName() {
        return movieName;
    }

    public int getBookingNo() {
        return bookingNo;
    }

    public int getRating() {
        return rating;
    }

    public int getPrice() {
        return price;
    }

    public int getTime() {
        return time;
    }

//    public int getHall_id() {  //org
//        return hall_id;
//    }
//
//    public int getSeatNo() {  //org
//        return seatNo;
//    }
    public HallType getHalltype() {
        return halltype;
    }


    public static int getTotalBookings() {
        return TotalBookings;
    }

    //Receptionist recep= new Receptionist();   // banady 3ala bcreate booking bta3t el receptionist
    //org
//    public Booking(String user_name, String recep_name, String type, String MovieName, int price, int time) {
//        this.user_name = user_name;
//        this.recep_name = recep_name;
//        this.type = type;
//        this.movieName = MovieName;
//        this.price = price;
//        this.time = time;
//        rating = -1;
//        TotalBookings++;
//        //this.hall_id = hall_id;
//    }
    public Booking(String user_name, String recep_name, String MovieName, int time,int[] arr ,Halls hall) {
        this.user_name = user_name;
        this.recep_name = recep_name;
        this.movieName = MovieName;
        this.time = time;
        rating = -1;
        TotalBookings++;
        this.halltype = hall.getHallType();
        this.hall = hall;
         bookingNo = TotalBookings + 1;
    }

    public Booking() {
        TotalBookings++;
    }

    //org
//    public void view() { //bt3t kol guest   //jana
//        System.out.println("Guest username: " + user_name);
//        System.out.println("Receptionist's Name: " + recep_name);
//        System.out.println("Type: " + type);
//        System.out.println("Name: " + movieName);
//        System.out.println("Price: " + price);
//        System.out.println("Time: " + time);
//         System.out.println(hall_id);
//    }
    public String view() {
        StringBuilder result = new StringBuilder();
        result.append("Guest username: ").append(user_name).append("\n");
        result.append("Receptionist's Name: ").append(recep_name).append("\n");
        result.append("Type: ").append(type).append("\n");
        result.append("Name: ").append(movieName).append("\n");
        result.append("Price: ").append(price).append("\n");
        result.append("Time: ").append(time).append("\n");
        result.append("\n");
        return result.toString();
    }

    //org
//    static public void viewAll() { //kol al booking al at3mlt   //jana
//        System.out.println("Viewing bookings: ");
//
//        for (Booking s : allbookings) {
//            System.out.println(s.bookingNo);
//            System.out.println(s.movieName);
//            System.out.println(s.time);
//        }
//    }
    static public String viewAll() { //kol al booking al at3mlt   //jana
        StringBuilder result = new StringBuilder();
        result.append("Viewing bookings: \n");

        for (Booking s : allbookings) {
            result.append("Booking No: ").append(s.bookingNo).append("\n");
            result.append("Movie Name: ").append(s.movieName).append("\n");
            result.append("Time: ").append(s.time).append("\n\n");
        }

        return result.toString();
    }

    public void writeToFile() {
        try {
            File file = new File("E:\\java\\oop project\\booking.txt");

            PrintWriter w = new PrintWriter(file);
            for (Booking b : allbookings) {
                w.println("Guest's username : " + b.getUser_name());
                w.println(" Receptionost's name : " + b.getRecep_name());
                w.println("Movie's name : " + b.getMovieName());
                w.println("Movies's category : " + b.getType());
                w.println("Time : " + b.getTime());
                w.println("Movies's price : " + b.getPrice());
                w.println("Movies's price : " + b.getPrice());
                w.println("Hall type : " + b.getHalltype());
                // w.println("Seat no : " + b.getSeatNo());
                w.println("Guest's rating : " + b.getRating());
                w.println("This is Booking no : " + b.getBookingNo());
                w.println();

            }
            w.println("Total bookings done : " + TotalBookings);
            w.close();

        } catch (IOException e) {
            System.out.println(e);
        }
    }

    public void viewReports() {
        try {

            File file = new File("E:\\java\\oop project\\booking.txt");

            Scanner s = new Scanner(file);
            while (s.hasNextLine()) {
                String read = s.nextLine();
                System.out.println(read);
            }
        } catch (IOException e) {
            System.out.println(e);
        }
    }
}
