package javaapplication14;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.Scanner;
import java.util.HashMap;
public class Movies{ // implements Media { leh implement

    private String imagePath;
    private int MoviePrice;
    private String MovieName;
    private String MovieCatgory;
    private int bookings;
    private int revenue;
    private int MovieId;
    private static HashMap<String, Movies> movieMap = new HashMap<>();
    private static ArrayList<Movies> Movies = new ArrayList<>();

    public Movies() {
    }

    public static ArrayList<Movies> getMovies() {
        return Movies;
    }

    public Movies( String MovieName,int MoviePrice, int movieID,  String MovieCatgory,String imagePath) {
        this.MoviePrice = MoviePrice;
        this.MovieName = MovieName;
        this.MovieCatgory = MovieCatgory;
        this.MovieId = movieID;
        this.bookings = 0;
        this.imagePath = imagePath;
        Movies.add(this);
    }

    public String getImagePath() {
        return imagePath;
    }

    
    

    public void setMoviePrice(int MoviePrice) {
        this.MoviePrice = MoviePrice;
    }

    public void setMovieName(String MovieName) {
        this.MovieName = MovieName;
    }

    public void setMovieCatgory(String MovieCatgory) {
        this.MovieCatgory = MovieCatgory;
    }

    public int getMoviePrice() {
        return MoviePrice;
    }

    public String getMovieName() {
        return MovieName;
    }
    public static boolean isMovie(String name){
        for(Movies s: Movies){
            if(s.MovieName.equalsIgnoreCase(name))
                return true;
        }
        return false;
    }
    public String getMovieCatgory() {
        return MovieCatgory;
    }

    public int getMovieId() {
        return MovieId;
    }

    public void setMovieId(int MovieId) {
        this.MovieId = MovieId;
    }
    
    public int getRevenue() {
        return revenue;
    }

    public String getName() {
        return MovieName;
    }

    public int getBookings() {
        return bookings;
    }

    public void book() {
        revenue = MoviePrice * bookings;
        bookings++;
    }

    public void viewReports() {
      try{
          
           File file=new File("\"C:\\Users\\Meno\\Documents\\NetBeansProjects\\JavaApplication27\\src\\javaapplication27\\mena.txt");
        
          Scanner s=new Scanner(file);
          while (s.hasNextLine()) {
                String read = s.nextLine();
                System.out.println(read);
            }
        } catch (IOException e) {
            System.out.println(e);
        }
    }

    public Movies mostBooked() {
        Movies mostBookedMovie = null;
        int maxNum = 0;

        for (Movies movie : movieMap.values()) {
            if (movie.getBookings() > maxNum) {
                maxNum = movie.getBookings();
                mostBookedMovie = movie;
            }
        }
        return mostBookedMovie;
    }

    public Movies mostRevenue() {
        Movies mostRevMovie = null;
        int maxRevenue = -1;

        for (Movies movie : movieMap.values()) {
            int revenue = movie.getMoviePrice() * movie.getBookings();
            if (revenue > maxRevenue) {
                maxRevenue = revenue;
                mostRevMovie = movie;
            }
        }
        return mostRevMovie;
    }
    
     public static ArrayList<String> getMovieNames() {  //j
        ArrayList<String> movieNames = new ArrayList<>();
        for (Movies movie : Movies) {
            movieNames.add(movie.getMovieName());
        }
        return movieNames;
    }

    public void writeToFile() {
        Movies m = new Movies();
        try {
            File file=new File("\"C:\\Users\\Meno\\Documents\\NetBeansProjects\\JavaApplication27\\src\\javaapplication27\\mena.txt");
        
            PrintWriter w = new PrintWriter(file);
            
            for (Movies movie : movieMap.values()) {
                w.println("Movie name: " + movie.getName() + ", " + "Category:" + MovieCatgory + ", " + "Total number of bookings: " + movie.getBookings());
            }
            Movies mostBookedMovie = mostBooked();
            if (mostBookedMovie != null) {
                w.println("The most booked movie is: " + mostBookedMovie.getName() + " with " + mostBookedMovie.getBookings() + " bookings.");
            }

            Movies mostRevMovie = mostRevenue();
            if (mostRevMovie != null) {
                int maxRevenue = mostRevMovie.getMoviePrice() * mostRevMovie.getBookings();
                w.println("The show " + mostRevMovie.getName() + " has the most revenue of value: " + maxRevenue);
            }
        } catch (IOException e) {
            System.out.println(e);
        }
    }

    
}